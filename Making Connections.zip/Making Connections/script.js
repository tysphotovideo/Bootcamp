function removeElement(){
    var remove = document.querySelector("#todd");
    remove.remove();
}
function removeElement2(){
    var remove = document.querySelector("#phil");
    remove.remove();
}

function changeName(){
    var change = document.querySelector("#jane")
    change.innerText = "Jill Biden";
}