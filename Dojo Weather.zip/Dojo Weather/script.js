function removeElement(){
    var remove = document.querySelector(".cookies");
    remove.remove();
}

function changeTemp(element){
    var change = document.querySelectorAll(".temperature")
    var temp = element.value
    console.log(change)
    for(var i=0; i<change.length; i++){
        if (temp == 'fahrenheit'){
            change[i].innerText = Math.round(change[i].innerText * 1.8 + 32);
        }else {
            change[i].innerText = Math.round((change[i].innerText - 32) / 1.8);
        }
    }
    
}

function cityAlert(element){
    alert('Alert')
}