var sum = 0
var product = 1
for(var i = 1; i<20; i+=2){
    console.log(i)   
}

for(var x = 100; x>0; x--){
    if(x % 3 == 0){
        console.log(x)
    }
}

for(var s = 4; s>-4; s-=1.5){
    console.log(s)
}
for(var f = 1; f<101; f++){
    sum+=f
}
for(var p = 1; p<13; p++){
    product *= p
}
console.log(sum)
console.log(product)


