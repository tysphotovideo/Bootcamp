function changeText(){
    var element = document.querySelector('.btn')
    element.innerHTML = "Logout"
}

function removeDef(){
        var remove = document.getElementById('def');
        remove.parentNode.removeChild(remove);
}

function liked(){
    alert('Ninja was Liked')
}